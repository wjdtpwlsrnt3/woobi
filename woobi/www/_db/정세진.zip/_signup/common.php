<?php
  $servername = "sejin1230.woobi.co.kr"; 
  $username = "sejin1230"; 
  $password = "skaksdml12";
  $db = "sejin1230";

  $conn = new mysqli($servername, $username, $password, $db);
?>